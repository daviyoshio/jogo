import pygame
import asyncio
import sys

async def main():
    pygame.init()
    pygame.mixer.init()

    largura, altura = 800, 600
    tela = pygame.display.set_mode((largura, altura))
    pygame.display.set_caption("O Desafio Impossível")

    clock = pygame.time.Clock()
    velocidade = 4

    som_estourado = None

    try:
        imagem_fundo = pygame.image.load("fundo.jpg").convert()
        imagem_fundo = pygame.transform.scale(imagem_fundo, (largura, altura))

        imagem_susto = pygame.image.load("susto.jpg").convert()
        imagem_susto = pygame.transform.scale(imagem_susto, (largura, altura))

        som_estourado = pygame.mixer.Sound("grito.ogg")
    except Exception as e:
        print(f"Erro ao carregar arquivos: {e}")
        imagem_fundo = pygame.Surface((largura, altura))
        imagem_fundo.fill((0, 0, 0))

        imagem_susto = pygame.Surface((largura, altura))
        imagem_susto.fill((255, 0, 0))

    jogador_pos = [50, 50]
    ponto_final = pygame.Rect(700, 500, 50, 50)

    sustou = False
    som_tocado = False
    rodando = True

    while rodando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                rodando = False

        if not sustou:
            teclas = pygame.key.get_pressed()
            if teclas[pygame.K_LEFT] and jogador_pos[0] > 0:
                jogador_pos[0] -= velocidade
            if teclas[pygame.K_RIGHT] and jogador_pos[0] < largura - 20:
                jogador_pos[0] += velocidade
            if teclas[pygame.K_UP] and jogador_pos[1] > 0:
                jogador_pos[1] -= velocidade
            if teclas[pygame.K_DOWN] and jogador_pos[1] < altura - 20:
                jogador_pos[1] += velocidade

            tela.blit(imagem_fundo, (0, 0))
            pygame.draw.rect(tela, (255, 0, 0), (jogador_pos[0], jogador_pos[1], 20, 20))
            pygame.draw.rect(tela, (0, 255, 0), ponto_final)

            corpo_jogador = pygame.Rect(jogador_pos[0], jogador_pos[1], 20, 20)
            if corpo_jogador.colliderect(ponto_final):
                sustou = True

        if sustou:
            if not som_tocado and som_estourado is not None:
                som_estourado.play()
                som_tocado = True
            tela.blit(imagem_susto, (0, 0))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())